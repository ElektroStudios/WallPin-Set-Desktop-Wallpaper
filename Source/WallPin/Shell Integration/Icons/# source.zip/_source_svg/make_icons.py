import io, os, struct
import cairosvg
from PIL import Image

OUT = "/mnt/user-data/outputs/Icons"
SVG_DIR = os.path.join(OUT, "_source_svg")
os.makedirs(SVG_DIR, exist_ok=True)

SIZES = [16, 20, 24, 32, 40, 48, 64]


import math
FRAME = "#8c97a6"   # mid gray: readable on light and dark menus
BLUE  = "#2d8cff"
WHITE = "#ffffff"

def wrap(body):
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="256" height="256" shape-rendering="crispEdges">'
            + body + '</svg>')

def frame():
    return f'<rect x="1.5" y="3.5" width="13" height="9" fill="none" stroke="{FRAME}" stroke-width="1"/>'

def star(cx, cy, ro, ri):
    pts = []
    for i in range(10):
        r = ro if i % 2 == 0 else ri
        a = -math.pi/2 + i*math.pi/5
        pts.append(f"{cx + r*math.cos(a):.2f},{cy + r*math.sin(a):.2f}")
    return f'<polygon points="{" ".join(pts)}" fill="{WHITE}" shape-rendering="geometricPrecision"/>'

def _old_cross_arrows():
    s = f'<g fill="{WHITE}" stroke="{WHITE}" stroke-width="1.2" shape-rendering="geometricPrecision">'
    s += '<line x1="4.5" y1="8" x2="11.5" y2="8"/><line x1="8" y1="5.5" x2="8" y2="10.5"/>'
    s += '<polygon stroke="none" points="2.8,8 5.2,5.9 5.2,10.1"/><polygon stroke="none" points="13.2,8 10.8,5.9 10.8,10.1"/>'
    s += '<polygon stroke="none" points="8,4.3 5.9,6.4 10.1,6.4"/><polygon stroke="none" points="8,11.7 5.9,9.6 10.1,9.6"/>'
    s += '</g>'
    return s


def px(cells, color=WHITE):
    return "".join(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{color}"/>' for x, y, w, h in cells)

def check():
    cells = [(x, y, 2, 2) for x, y in ((4,8),(5,9),(6,10),(7,9),(8,8),(9,7),(10,6))]
    return px(cells)

def cross_arrows():
    cells = [
        (5, 7, 6, 2),                                  # shaft
        (2, 7, 1, 2), (3, 6, 1, 4), (4, 5, 1, 6),      # left head
        (13, 7, 1, 2), (12, 6, 1, 4), (11, 5, 1, 6),   # right head
    ]
    return px(cells)

icons = {
    "default": wrap(frame() + f'<rect x="2" y="4" width="12" height="8" fill="{BLUE}"/>' + check()),
    "center":  wrap(frame() + f'<rect x="5" y="6" width="6" height="4" fill="{BLUE}"/>'),
    "tile":    wrap(frame() + "".join(f'<rect x="{x}" y="{y}" width="5" height="3" fill="{BLUE}"/>'
                                     for x in (2, 9) for y in (4, 9))),
    "stretch": wrap(frame() + f'<rect x="2" y="4" width="12" height="8" fill="{BLUE}"/>' + cross_arrows()),
    "fit":     wrap(frame() + f'<rect x="2" y="4" width="2" height="8" fill="{FRAME}" opacity="0.55"/>'
                            f'<rect x="12" y="4" width="2" height="8" fill="{FRAME}" opacity="0.55"/>'
                            f'<rect x="4" y="4" width="8" height="8" fill="{BLUE}"/>'),
    "fill":    wrap(f'<rect x="0" y="2" width="16" height="12" fill="{BLUE}" opacity="0.35"/>' + frame() +
                    f'<rect x="2" y="4" width="12" height="8" fill="{BLUE}"/>'),
    "span":    wrap('<rect x="0.5" y="3.5" width="7" height="9" fill="none" stroke="%s" stroke-width="1"/>' % FRAME +
                    '<rect x="8.5" y="3.5" width="7" height="9" fill="none" stroke="%s" stroke-width="1"/>' % FRAME +
                    f'<rect x="1" y="5" width="14" height="6" fill="{BLUE}"/>'),
}
def dib_entry(img):
    """32-bit BMP (DIB) payload for an ICO entry, bottom-up BGRA + AND mask."""
    w, h = img.size
    px = img.convert("RGBA").load()
    xor = bytearray()
    for y in range(h - 1, -1, -1):
        for x in range(w):
            r, g, b, a = px[x, y]
            xor += bytes((b, g, r, a))
    row = ((w + 31) // 32) * 4
    mask = bytes(row * h)  # alpha channel drives transparency
    hdr = struct.pack("<IiiHHIIiiII", 40, w, h * 2, 1, 32, 0, len(xor) + len(mask), 0, 0, 0, 0)
    return hdr + bytes(xor) + mask

def png_entry(img):
    b = io.BytesIO(); img.save(b, "PNG"); return b.getvalue()

def build_ico(svg, path):
    entries = []
    for s in SIZES:
        png = cairosvg.svg2png(bytestring=svg.encode(), output_width=s, output_height=s)
        img = Image.open(io.BytesIO(png)).convert("RGBA")
        data = png_entry(img) if s >= 64 else dib_entry(img)
        entries.append((s, data))
    out = struct.pack("<HHH", 0, 1, len(entries))
    offset = 6 + 16 * len(entries)
    blobs = b""
    for s, data in entries:
        out += struct.pack("<BBBBHHII", s % 256, s % 256, 0, 0, 1, 32, len(data), offset + len(blobs))
        blobs += data
    with open(path, "wb") as f:
        f.write(out + blobs)


for name, svg in icons.items():
    with open(os.path.join(SVG_DIR, f"{name}.svg"), "w") as f:
        f.write(svg)
    build_ico(svg, os.path.join(OUT, f"{name}.ico"))

# preview: real size (16, 24) + 8x nearest-neighbour zoom of the 16px version, on light and dark
W = len(icons) * 150
sheet = Image.new("RGBA", (W, 2 * 170), (255, 255, 255, 255))
sheet.paste(Image.new("RGBA", (W, 170), (32, 32, 32, 255)), (0, 170))
def render(svg, s):
    return Image.open(io.BytesIO(cairosvg.svg2png(bytestring=svg.encode(), output_width=s, output_height=s))).convert("RGBA")
for i, (name, svg) in enumerate(icons.items()):
    for row in range(2):
        ox, oy = i * 150 + 10, row * 170 + 10
        z = render(svg, 16).resize((128, 128), Image.NEAREST)
        sheet.alpha_composite(z, (ox, oy))
        sheet.alpha_composite(render(svg, 16), (ox, oy + 135))
        sheet.alpha_composite(render(svg, 24), (ox + 30, oy + 131))
        sheet.alpha_composite(render(svg, 32), (ox + 70, oy + 127))
sheet.convert("RGB").save("/home/claude/preview.png")
print("ok")
